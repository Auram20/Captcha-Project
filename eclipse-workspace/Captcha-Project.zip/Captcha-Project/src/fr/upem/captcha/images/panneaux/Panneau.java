package fr.upem.captcha.images.panneaux;

import fr.upem.captcha.images.Specific;

final public class Panneau extends Specific {
	
	public Panneau() {
		super();
		System.out.println("Panneau");
		load();
	}
	

}