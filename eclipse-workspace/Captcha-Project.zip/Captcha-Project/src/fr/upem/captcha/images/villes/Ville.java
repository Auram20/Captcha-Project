package fr.upem.captcha.images.villes;

import fr.upem.captcha.images.Specific;

final public class Ville extends Specific {
	
	public Ville() {
		super();
		System.out.println("Ville");
		load();
	}
	

}
