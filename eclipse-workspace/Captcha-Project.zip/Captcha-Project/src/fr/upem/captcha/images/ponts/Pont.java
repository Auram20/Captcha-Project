package fr.upem.captcha.images.ponts;

import fr.upem.captcha.images.Specific;

final public class Pont extends Specific {
	
	public Pont() {
		super();
		System.out.println("Pont");
		load();
	}
	

}